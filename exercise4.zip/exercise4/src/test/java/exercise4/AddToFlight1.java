package exercise4;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.Status;

import exercise4.ClsReport;

public class AddToFlight1 extends ClsBrowser{
	//Locators
	        By captchaBtn = By.xpath("//*[@id=\"recaptcha-anchor\"]");
	
			
	        By firstBtn = By.xpath("//div[@class='col btnSearch SearchOrigin']");
	        
	        By nameoriginBtn = By.xpath("//*[@id=\"fnameOrigin\"]");
	     
	        By nameoriginBtn2 = By.id("fnameDestination");
			
			;
	        By guadalajaraBtn = By.xpath("//div[@class='col-10 left-align' and text() = 'Guadalajara']");
			
	        By cancunBtn = By.xpath("//div[@class='col-10 left-align' and text() = 'Canc�n']");
			
	        By seeoptionsBtn = By.xpath("(//a[@href='javascript:void(0);'])[7]");
	        
			By passBtn = By.xpath("//span[@class='pickerright icon-carousel-iconleft']");
			
			By firstdayBtn = By.xpath("//td[@class='weekend datecell-20221029 customfare available']");
			
			By seconddayBtn = By.xpath("//td[@class='datecell-20221104 returnVisible returnCustomfare available']");
			
			By factBtn = By.xpath("//button[@class='btn-calendar d-none d-md-block mat-flat-button mat-button-base mat-secondary']\r\n"
					+ "");
			
			By searchBtn = By.xpath("//button[@class='btn btn-large col-12 search-btn mat-flat-button mat-button-base mat-primary']\r\n"
					+ "");
			
			//By flightBtn = By.xpath("//*[@id=\"Flightlists\"]/mbs-flight-lists/div[2]/div[1]/div/div[2]/div/div[1]/a/span[2]");
			By flightBtn = By.xpath("\"(//div[@class='d-none d-md-block price ng-star-inserted'])[1]\"");
			////body[1]/mbs-root[1]/div[1]/section[1]/mbs-flight[1]/div[1]/div[1]/section[1]/div[6]/mbs-flight-lists[1]/div[2]/div[1]/mbs-flight-fares[1]/div[1]/div[1]/div[1]/mat-card[1]
			//By flightListBtn = By.xpath("//*[@id=\"Flightlists\"]");
			
	
	public void AddToFlight1() {
		
		
		
		try 
        {
			WaitForLoad();
			click(firstBtn);
			WaitForLoad();
			WaitForLoad();
			WaitForLoad();
			click(nameoriginBtn);
			WaitForLoad();
			WaitForLoad();
			WaitForLoad();
			click(nameoriginBtn);
			WaitForLoad();
			WaitForLoad();
			type("Guadalajara",nameoriginBtn);
			WaitForLoad();
			WaitForLoad();
			WaitForLoad();
			click(guadalajaraBtn);
			WaitForLoad();
			WaitForLoad();
			WaitForLoad();
			click(nameoriginBtn2);
			WaitForLoad();
			WaitForLoad();
			WaitForLoad();
			type("Canc�n",nameoriginBtn2);
			WaitForLoad();
			WaitForLoad();
			WaitForLoad();
			click(cancunBtn);
			WaitForLoad();
			WaitForLoad();
			WaitForLoad();
			click(passBtn);
			WaitForLoad();
			WaitForLoad();
			WaitForLoad();
			click(passBtn);
			WaitForLoad();
			WaitForLoad();
			WaitForLoad();
			click(passBtn);
			WaitForLoad();
			WaitForLoad();
			WaitForLoad();
			click(passBtn);
			WaitForLoad();
			WaitForLoad();
			WaitForLoad();
			click(passBtn);
			WaitForLoad();
			WaitForLoad();
			WaitForLoad();
			WaitForLoad();
			click(passBtn);
			//WaitForLoad();
			//click(passBtn);
			WaitForLoad();
			WaitForLoad();
			WaitForLoad();
			WaitForLoad();
			WaitForLoad();
			WaitForLoad();
			click(firstdayBtn);
			WaitForLoad();
			WaitForLoad();
			WaitForLoad();
			WaitForLoad();
			WaitForLoad();
			WaitForLoad();
			click(seconddayBtn);
			WaitForLoad();
			WaitForLoad();
			WaitForLoad();
			WaitForLoad();
			click(factBtn);
			WaitForLoad();
			//WaitForLoad();
			//WaitForLoad();
			//WaitForLoad();
			click(searchBtn);
			WaitForLoad();
			WaitForLoad();
			WaitForLoad();
			WaitForLoad();
			WaitForLoad();
			WaitForLoad();
			click(flightBtn);
			WaitForLoad();
        }catch(Exception e) 
        {
        	  //ClsReport.fnLog(Status.FAIL, "Error ", false);
  	      System.out.println("No element was found in this part");
  	      
           return;
           
           }
		
		
	}

}
