package exercise4;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.testng.annotations.BeforeMethod;

import com.aventstack.extentreports.Status;

import exercise4.AddToFlight1;
import exercise4.ClsBrowser;
//import exercise4.ClsReport;
//import selenium.ClsReport;


public class Test4 extends ClsBrowser{
	AddToFlight1 addToFlight1;
/*
	@BeforeMethod
	public static void beforeClass() 
	{
		ClsReport.fnSetupReport();
	}
	*/
	@Before
	public void setUp() throws Exception {
		
		addToFlight1 = new AddToFlight1();
		ClsBrowser.BrowserName = "Chrome";
		OpenBrowser();
	}

	@After
	public void tearDown() throws Exception {
		//CloseBrowser();
		System.out.println("No flight cost less than $1500 MXN");
	}

	@Test
	public void test() {
		/*
		try {
			NavigateToUrl("https://www.volaris.com/");
			addToFlight1.AddToFlight1();
			
		}
			catch(Exception e) 
	        {
	        	  ClsReport.fnLog(Status.FAIL, "Error ", false);
	           }
		*/
		
		
		NavigateToUrl("https://www.volaris.com/");
		addToFlight1.AddToFlight1();
		//ClsReport.fnLog(Status.FAIL, "Error ", false);
	}

}
